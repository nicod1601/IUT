package pac.inter;

public class IFrabrication 
{
    public double getSurfaceExterne();
    public double getVolumeInterne();
}
