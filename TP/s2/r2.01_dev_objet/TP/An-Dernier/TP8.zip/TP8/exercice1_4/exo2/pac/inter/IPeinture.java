package pac.inter;
import pac.emballage.*;

public interface IPeinture 
{
	public double getSurfaceExterne();
}