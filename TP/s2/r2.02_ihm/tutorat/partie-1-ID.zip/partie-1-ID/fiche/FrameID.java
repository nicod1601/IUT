import javax.swing.*;

public class FrameID extends JFrame
{

    public FrameID()
    {
        /*--------------------------*/
        /* Création des composants  */
        /*--------------------------*/


        /*---------------------------*/
        /*   Position des composants */
        /*---------------------------*/
    }
}