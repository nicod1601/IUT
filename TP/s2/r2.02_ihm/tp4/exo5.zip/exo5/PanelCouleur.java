import java.awt.*;

public class PanelCouleur extends Panel
{
	public PanelCouleur()
	{
		this.setLayout(new BorderLayout());
		/* ------------------------------ */
		/* Création des composants        */
		/* ------------------------------ */

		/* ------------------------------ */
		/* Positionnement des composants  */
		/* ------------------------------ */
		this.add(new Label());

		/* ------------------------------ */
		/* Activation des composants      */
		/* ------------------------------ */
		
	}
}
